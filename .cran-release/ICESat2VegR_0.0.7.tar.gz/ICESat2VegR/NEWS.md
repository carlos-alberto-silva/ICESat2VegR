# ICESat2VegR 0.0.7

* Fix Python environment configuration: declare managed requirements before
  starting Python, reuse existing environments, and recheck modules after
  installation attempts.
* Improve conda fallback creation and diagnostics without changing global
  conda channel settings. Add controls for managed environments and automatic
  Miniconda installation.
* Preserve positional argument compatibility, quote conda command arguments,
  correct the conda-to-pip fallback, and report failed RStudio restarts.
