#' Fit and estimate ground elevation for photons or arbitrary distances
#' from the track beginning
#'
#' @description
#' Function to estimate ground elevation using smoothing and
#' interpolation functions. Ground photons (classed_pc_flag == 1) are
#' first aggregated within a smoothing window, then an interpolation
#' function is applied to estimate the ground elevation at each photon
#' location or at arbitrary distances along the track.
#'
#' @param atl03_atl08_seg_dt An S4 object of class
#'   [`ICESat2VegR::icesat2.atl03_atl08_seg_dt-class`] containing ATL03
#'   and ATL08 data (output of [ATL03_ATL08_segment_create()] function).
#' @param smoothing_window numeric. The smoothing window size in meters
#'   for aggregating ground photons before interpolation.
#'   Default is \code{NA}, which uses the ATBD adaptive window size.
#'   See Details for more information.
#' @param smoothing_func function. The aggregation function applied to
#'   ground photon elevations within each smoothing window.
#'   Default is \code{median}.
#' @param interpolation_func function. The interpolation function used
#'   to estimate ground elevation from the smoothed ground photons.
#'   Default is \code{NA}, which falls back to \code{stats::approxfun}.
#'   See Details for more information.
#' @param xout_parameter_name character. The name of the parameter used
#'   by \code{interpolation_func} to receive the prediction vector.
#'   When set to \code{"xout"} (default), the function predicts ground
#'   elevation at every photon's \code{dist_ph_along} position.
#'   When set to \code{NA}, the raw output of \code{interpolation_func}
#'   is returned directly without predicting at photon locations (useful
#'   when \code{interpolation_func} returns a function, e.g.
#'   \code{approxfun}). See Details for more information.
#' @param ... Optional additional parameters passed to
#'   \code{interpolation_func}. See Details for more information.
#'
#' @return When \code{xout_parameter_name} is not \code{NA}, returns a
#'   named list with two numeric vectors:
#'   \describe{
#'     \item{x}{Distance along track (\code{dist_ph_along}) for each
#'       photon, in meters.}
#'     \item{y}{Interpolated ground elevation (\code{h_ph}) at each
#'       photon location, in meters. Values are \code{NA} for photons
#'       outside the smoothed ground range (controlled by the
#'       \code{rule} argument of the interpolation function).}
#'   }
#'   When \code{xout_parameter_name = NA}, returns the raw output of
#'   \code{interpolation_func} directly — for example, a callable
#'   \code{function} when \code{interpolation_func = approxfun}, which
#'   can then be evaluated at arbitrary distances along the track.
#'
#' @details
#' The function for calculating the ground will first pass a smoothing
#' window with \code{smoothing_window} size, applying the
#' \code{smoothing_func} to aggregate the ground photons
#' (\code{classed_pc_flag == 1}).
#'
#' Then it will use an interpolation function between those aggregated
#' photons to estimate a smooth ground surface.
#'
#' The \code{smoothing_func} signature will depend on the function used.
#' It is assumed that the first two arguments are vectors of \code{x}
#' (independent variable) and \code{y} (the values to be aggregated).
#' The remaining arguments are passed through \code{...}.
#'
#' The interpolation functions need a third parameter which is the
#' \code{x} vector to predict at. Functions from the \code{stats} base
#' package such as \code{stats::approx()} and \code{stats::spline()}
#' name this argument \code{xout}, so you can use:
#'
#' ```
#' ATL03_ATL08_photons_seg_dt_fitground(
#'   atl03_atl08_seg_dt,
#'   interpolation_func = approx,
#'   xout_parameter_name = "xout"
#' )
#' ```
#'
#' to predict at every photon location along the track. Other functions
#' may name the prediction parameter differently — for example,
#' \code{signal::pchip()} uses \code{xi} instead of \code{xout}.
#' The \code{pchip} algorithm (as implemented in the
#' \strong{signal} package) is the algorithm used by the ATL08 ATBD.
#'
#' The \code{smoothing_window} can be left \code{NA}, which will use
#' the ATBD adaptive algorithm for calculating the window size:
#'
#' \eqn{Sspan = \lceil 5 + 46 \times (1 - e^{-a \times length}) \rceil},
#' where \emph{length} is the number of photons within the segment.
#'
#' \deqn{a \approx 21 \times 10^{-6}}
#'
#' \deqn{window\_size = \frac{2}{3} \times Sspan}
#'
#' This is not the same algorithm as used in ATL08 but is an adapted
#' version that uses the ATL08 pre-classification.
#'
#' @examples
#' if (requireNamespace("hdf5r", quietly = TRUE)) {
#' # Specifying the path to ATL03 and ATL08 files
#' atl03_path <- system.file("extdata", "atl03_clip.h5", package = "ICESat2VegR")
#' atl08_path <- system.file("extdata", "atl08_clip.h5", package = "ICESat2VegR")
#'
#' # Reading ATL03 and ATL08 data (h5 files)
#' atl03_h5 <- ATL03_read(atl03_path = atl03_path)
#' atl08_h5 <- ATL08_read(atl08_path = atl08_path)
#'
#' # Extracting ATL03 and ATL08 photons and heights
#' atl03_atl08_dt <- ATL03_ATL08_photons_attributes_dt_join(atl03_h5, atl08_h5)
#'
#' # Converting to seg_dt class (required input for fitground)
#' atl03_atl08_seg_dt <- ATL03_ATL08_segment_create(
#'   atl03_atl08_dt,
#'   segment_length = 30
#' )
#'
#' # Example 1: ATBD adaptive smoothing window + linear interpolation
#' # at each photon location along the track.
#' # Returns a list with $x (dist_ph_along) and $y (ground elevation in meters).
#' # NAs appear at photon locations outside the smoothed ground range.
#' ground_approx <- ATL03_ATL08_photons_seg_dt_fitground(
#'   atl03_atl08_seg_dt,
#'   interpolation_func = approx,
#'   xout_parameter_name = "xout"
#' )
#' head(ground_approx$x) # photon distances along track (meters)
#' head(ground_approx$y) # interpolated ground elevations (meters)
#'
#' # Example 2: Return an interpolation function (approxfun) for
#' # querying ground elevation at arbitrary distances along the track.
#' # xout_parameter_name = NA skips prediction at photon locations
#' # and returns the interpolation function directly.
#' ground_fun <- ATL03_ATL08_photons_seg_dt_fitground(
#'   atl03_atl08_seg_dt,
#'   interpolation_func = approxfun,
#'   xout_parameter_name = NA
#' )
#' # Query ground elevation at custom distances along track (meters)
#' ground_fun(c(100, 200, 300))
#'
#' # Example 3: Fixed 5 m smoothing window using mean instead of median
#' ground_mean <- ATL03_ATL08_photons_seg_dt_fitground(
#'   atl03_atl08_seg_dt,
#'   smoothing_window = 5,
#'   smoothing_func = mean,
#'   interpolation_func = approx,
#'   xout_parameter_name = "xout"
#' )
#' head(ground_mean$y)
#'
#' close(atl03_h5)
#' close(atl08_h5)
#' }
#' @import data.table
#' @export
ATL03_ATL08_photons_seg_dt_fitground <- function(
    atl03_atl08_seg_dt,
    smoothing_window = NA,
    smoothing_func = median,
    interpolation_func = NA,
    xout_parameter_name = "xout",
    ...) {
  classed_pc_flag <-
    dist_ph_along <-
    segment_id <-
    h_ph <- NA

  stopifnot(
    "atl03_atl08_seg_dt seems to be invalid, use the package function" =
      inherits(atl03_atl08_seg_dt, "icesat2.atl03_atl08_seg_dt")
  )

  if (!inherits(interpolation_func, "function")) {
    interpolation_func <- approxfun
  }

  windowSize <- NA
  if (!is.numeric(smoothing_window)) {
    windowSize <- atl03_atl08_seg_dt[
      classed_pc_flag > 0,
      list(smoothing_window = 2 / 3 * ceiling(5 + 46 * (1 - exp(-21e-6 * .N)))),
      by = segment_id
    ]
  }

  ground_photons <- atl03_atl08_seg_dt[
    classed_pc_flag == 1 # Use only ground photons
  ]


  if (!is.numeric(smoothing_window)) {
    ground_photons <- ground_photons[windowSize, , on = "segment_id"]
  }

  smoothed <- ground_photons[
    ,
    list(h_ph = smoothing_func(h_ph)),
    by = list(
      dist_ph_along = floor(
        dist_ph_along / smoothing_window
      ) * smoothing_window + (smoothing_window / 2)
    ),
  ][order(dist_ph_along)][
    !is.na(dist_ph_along),
    list(
      dist_ph_along,
      h_ph
    )
  ]

  if (is.na(xout_parameter_name)) {
    return(interpolation_func(
      smoothed$dist_ph_along,
      smoothed$h_ph,
      ...
    ))
  } else {
    params <- list(
      smoothed$dist_ph_along,
      smoothed$h_ph,
      ...
    )
    params[[xout_parameter_name]] <-
      atl03_atl08_seg_dt$dist_ph_along

    return(do.call(
      interpolation_func,
      params
    ))
  }
}
