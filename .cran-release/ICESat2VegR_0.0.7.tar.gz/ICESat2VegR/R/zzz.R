# CRAN notes for data.table/dplyr dot usage
if (getRversion() >= "2.15.1") {
  utils::globalVariables(c("."))
}
#' The pointer to the `earthaccess` python reticulate module
#'
#' @useDynLib ICESat2VegR
#' @import Rcpp Rdpack mathjaxr
#' @importFrom Rdpack reprompt
#' @keywords internal
earthaccess <- NULL

#' The pointer to the `earth-engine-api` python reticulate module
#'
#' @seealso https://developers.google.com/earth-engine/apidocs
#' @export
ee <- NULL

# Private h5py module
h5py <- NULL

# Private pkg_module
pkg_module <- NULL

# Private cache for the Earth Engine search
ee_cache <- new.env(parent = emptyenv())
ee_cache$search <- NULL

.onLoad <- function(libname, pkgname) {
  # Create lazy module proxies without selecting or starting Python. Cloud
  # dependencies are resolved only when a cloud or Earth Engine feature is
  # actually used; ordinary package loading must remain Python-independent.
  earthaccess <<- reticulate::import(
    "earthaccess", convert = FALSE, delay_load = TRUE
  )
  ee <<- reticulate::import("ee", convert = TRUE, delay_load = TRUE)
  h5py <<- reticulate::import("h5py", convert = TRUE, delay_load = TRUE)

  # GDAL module load
  loadGdal()

  # Rcpp module load
  pkg_module <<- Rcpp::Module("icesat2_module")
}


loadGdal <- function() {
  Rcpp::loadModule("gdal_module", TRUE, TRUE)
  # Let the installed GDAL/PROJ libraries locate their matching data files.
  InitializeGDAL()
}

.onUnload <- function(libpath) {
  library.dynam.unload("ICESat2VegR", libpath)
}

.onAttach <- function(lib, pkg) {
  info <- utils::packageDescription("ICESat2VegR")
  if (is.null(info$Date)) {
    info$Date <- "2024-03-06 UTC"
  }
  base::packageStartupMessage(
    paste(
      "\n##----------------------------------------------------------------##\n",
      "##  ICESat2VegR package, version ", info$Version, ", Released ", info$Date,
      "    #",
      "\n##----------------------------------------------------------------##\n",
      "\n",
      "This package is developed by Carlos A. Silva (c.silva@ufl.edu), \n",
      "Caio Hamamura (caiohamamura@gmail.com), \n",
      "Cesar Alvites (c.alvitesdiaz@ufl.edu) and \n",
      "Alexander J. Gaskins (alexandergaskins@ufl.edu) from the Forest Biometrics \n",
      "Remote Sensing and AI Lab (SilvaLab) at the University of Florida. \n",
      "ICESat2VegR is based upon work supported by NASA's Ice, Cloud, and \n",
      "Land Elevation Satellite (ICESat2), Carbon Monitoring System (CMS), \n",
      "and Commercial Smallsat Data Scientific Analysis (CSDSA) under \n",
      "grants No. 80NSSC23K0941, 80NSSC23K1257, and 80NSSC24K0055. \n",
      "\n",
      "##----------------------------------------------------------------##",
      sep = ""
    )
  )
}

