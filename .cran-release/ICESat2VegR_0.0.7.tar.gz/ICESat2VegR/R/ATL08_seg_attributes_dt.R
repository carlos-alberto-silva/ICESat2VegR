# ATL08.var.map
ATL08.var.map <- list()
ATL08.var.map[["segment_watermask"]] <- "/land_segments/segment_watermask"
ATL08.var.map[["delta_time_end"]] <- "/land_segments/delta_time_end"
ATL08.var.map[["latitude_20m"]] <- "/land_segments/latitude_20m"
ATL08.var.map[["rgt"]] <- "/land_segments/rgt"
ATL08.var.map[["dem_flag"]] <- "/land_segments/dem_flag"
ATL08.var.map[["msw_flag"]] <- "/land_segments/msw_flag"
ATL08.var.map[["cloud_flag_atm"]] <- "/land_segments/cloud_flag_atm"
ATL08.var.map[["snr"]] <- "/land_segments/snr"
ATL08.var.map[["canopy"]] <- "/land_segments/canopy"
ATL08.var.map[["sigma_across"]] <- "/land_segments/sigma_across"
ATL08.var.map[["terrain"]] <- "/land_segments/terrain"
ATL08.var.map[["layer_flag"]] <- "/land_segments/layer_flag"
ATL08.var.map[["segment_snowcover"]] <- "/land_segments/segment_snowcover"
ATL08.var.map[["beam_azimuth"]] <- "/land_segments/beam_azimuth"
ATL08.var.map[["solar_azimuth"]] <- "/land_segments/solar_azimuth"
ATL08.var.map[["psf_flag"]] <- "/land_segments/psf_flag"
ATL08.var.map[["longitude"]] <- "/land_segments/longitude"
ATL08.var.map[["latitude"]] <- "/land_segments/latitude"
ATL08.var.map[["segment_id_end"]] <- "/land_segments/segment_id_end"
ATL08.var.map[["longitude_20m"]] <- "/land_segments/longitude_20m"
ATL08.var.map[["surf_type"]] <- "/land_segments/surf_type"
ATL08.var.map[["brightness_flag"]] <- "/land_segments/brightness_flag"
ATL08.var.map[["segment_landcover"]] <- "/land_segments/segment_landcover"
ATL08.var.map[["ph_removal_flag"]] <- "/land_segments/ph_removal_flag"
ATL08.var.map[["asr"]] <- "/land_segments/asr"
ATL08.var.map[["sigma_atlas_land"]] <- "/land_segments/sigma_atlas_land"
ATL08.var.map[["segment_id_beg"]] <- "/land_segments/segment_id_beg"
ATL08.var.map[["sigma_along"]] <- "/land_segments/sigma_along"
ATL08.var.map[["dem_h"]] <- "/land_segments/dem_h"
ATL08.var.map[["beam_coelev"]] <- "/land_segments/beam_coelev"
ATL08.var.map[["sat_flag"]] <- "/land_segments/sat_flag"
ATL08.var.map[["sigma_topo"]] <- "/land_segments/sigma_topo"
ATL08.var.map[["night_flag"]] <- "/land_segments/night_flag"
ATL08.var.map[["delta_time_beg"]] <- "/land_segments/delta_time_beg"
ATL08.var.map[["sigma_h"]] <- "/land_segments/sigma_h"
ATL08.var.map[["last_seg_extend"]] <- "/land_segments/last_seg_extend"
ATL08.var.map[["atlas_pa"]] <- "/land_segments/atlas_pa"
ATL08.var.map[["ph_ndx_beg"]] <- "/land_segments/ph_ndx_beg"
ATL08.var.map[["solar_elevation"]] <- "/land_segments/solar_elevation"
ATL08.var.map[["delta_time"]] <- "/land_segments/delta_time"
ATL08.var.map[["cloud_fold_flag"]] <- "/land_segments/cloud_fold_flag"
ATL08.var.map[["column_od_asr"]] <- "/land_segments/column_od_asr"
ATL08.var.map[["n_seg_ph"]] <- "/land_segments/n_seg_ph"
ATL08.var.map[["terrain_flg"]] <- "/land_segments/terrain_flg"
ATL08.var.map[["urban_flag"]] <- "/land_segments/urban_flag"
ATL08.var.map[["dem_removal_flag"]] <- "/land_segments/dem_removal_flag"
ATL08.var.map[["h_dif_ref"]] <- "/land_segments/h_dif_ref"
ATL08.var.map[["can_noise"]] <- "/land_segments/canopy/can_noise"
ATL08.var.map[["can_quality_score"]] <- "/land_segments/canopy/can_quality_score"
ATL08.var.map[["canopy_h_metrics_abs"]] <- "/land_segments/canopy/canopy_h_metrics_abs"
ATL08.var.map[["canopy_openness"]] <- "/land_segments/canopy/canopy_openness"
ATL08.var.map[["h_canopy"]] <- "/land_segments/canopy/h_canopy"
ATL08.var.map[["canopy_rh_conf"]] <- "/land_segments/canopy/canopy_rh_conf"
ATL08.var.map[["h_median_canopy_abs"]] <- "/land_segments/canopy/h_median_canopy_abs"
ATL08.var.map[["h_min_canopy"]] <- "/land_segments/canopy/h_min_canopy"
ATL08.var.map[["h_mean_canopy_abs"]] <- "/land_segments/canopy/h_mean_canopy_abs"
ATL08.var.map[["h_median_canopy"]] <- "/land_segments/canopy/h_median_canopy"
ATL08.var.map[["h_canopy_abs"]] <- "/land_segments/canopy/h_canopy_abs"
ATL08.var.map[["toc_roughness"]] <- "/land_segments/canopy/toc_roughness"
ATL08.var.map[["h_min_canopy_abs"]] <- "/land_segments/canopy/h_min_canopy_abs"
ATL08.var.map[["h_dif_canopy"]] <- "/land_segments/canopy/h_dif_canopy"
ATL08.var.map[["h_canopy_quad"]] <- "/land_segments/canopy/h_canopy_quad"
ATL08.var.map[["h_canopy_20m"]] <- "/land_segments/canopy/h_canopy_20m"
ATL08.var.map[["n_ca_photons"]] <- "/land_segments/canopy/n_ca_photons"
ATL08.var.map[["photon_rate_can"]] <- "/land_segments/canopy/photon_rate_can"
ATL08.var.map[["photon_rate_can_nr"]] <- "/land_segments/canopy/photon_rate_can_nr"
ATL08.var.map[["centroid_height"]] <- "/land_segments/canopy/centroid_height"
ATL08.var.map[["h_mean_canopy"]] <- "/land_segments/canopy/h_mean_canopy"
ATL08.var.map[["subset_can_flag"]] <- "/land_segments/canopy/subset_can_flag"
ATL08.var.map[["canopy_h_metrics"]] <- "/land_segments/canopy/canopy_h_metrics"
ATL08.var.map[["n_toc_photons"]] <- "/land_segments/canopy/n_toc_photons"
ATL08.var.map[["h_max_canopy_abs"]] <- "/land_segments/canopy/h_max_canopy_abs"
ATL08.var.map[["h_canopy_uncertainty"]] <- "/land_segments/canopy/h_canopy_uncertainty"
ATL08.var.map[["h_max_canopy"]] <- "/land_segments/canopy/h_max_canopy"
ATL08.var.map[["segment_cover"]] <- "/land_segments/canopy/segment_cover"
ATL08.var.map[["h_te_best_fit"]] <- "/land_segments/terrain/h_te_best_fit"
ATL08.var.map[["h_te_best_fit_20m"]] <- "/land_segments/terrain/h_te_best_fit_20m"
ATL08.var.map[["h_te_interp"]] <- "/land_segments/terrain/h_te_interp"
ATL08.var.map[["h_te_max"]] <- "/land_segments/terrain/h_te_max"
ATL08.var.map[["h_te_mean"]] <- "/land_segments/terrain/h_te_mean"
ATL08.var.map[["h_te_median"]] <- "/land_segments/terrain/h_te_median"
ATL08.var.map[["h_te_mode"]] <- "/land_segments/terrain/h_te_mode"
ATL08.var.map[["h_te_rh25"]] <- "/land_segments/terrain/h_te_rh25"
ATL08.var.map[["h_te_skew"]] <- "/land_segments/terrain/h_te_skew"
ATL08.var.map[["h_te_std"]] <- "/land_segments/terrain/h_te_std"
ATL08.var.map[["h_te_uncertainty"]] <- "/land_segments/terrain/h_te_uncertainty"
ATL08.var.map[["n_te_photons"]] <- "/land_segments/terrain/n_te_photons"
ATL08.var.map[["photon_rate_te"]] <- "/land_segments/terrain/photon_rate_te"
ATL08.var.map[["subset_te_flag"]] <- "/land_segments/terrain/subset_te_flag"
ATL08.var.map[["te_quality_score"]] <- "/land_segments/terrain/te_quality_score"
ATL08.var.map[["terrain_slope"]] <- "/land_segments/terrain/terrain_slope"
ATL08.var.map[["night_flag"]] <- "/land_segments/night_flag"
ATL08.var.map[["permafrost_alt"]] <- "/land_segments/permafrost_alt"
ATL08.var.map[["permafrost_prob"]] <- "/land_segments/permafrost_prob"

#' ATL08 Terrain and Canopy Attributes
#'
#' @description This function extracts terrain and canopy attributes by segments from ICESat-2 ATL08 data
#'
#' @param atl08_h5 A ICESat-2 ATL08 object (output of [ATL08_read()] function).
#' An S4 object of class [`ICESat2VegR::icesat2.atl08_dt-class`].
#' @param beam Character vector indicating beams to process (e.g. "gt1l", "gt1r", "gt2l", "gt2r", "gt3l", "gt3r")
#' @param attributes A character vector containing the list of terrain and canopy attributes to be extracted.
#' Default is attribute = c("h_canopy","canopy_h_metrics","canopy_openness","h_te_mean","h_te_median","terrain_slope")
#' @return Returns an S4 object of class [`ICESat2VegR::icesat2.atl08_dt-class`]
#' containing the ATL08-derived terrain and canopy attributes by segments.
#'
#' @details
#'
#' ## Segment-level attributes
#'
#' - `segment_id_beg`
#' - `segment_id_end`
#' - `delta_time`
#' - `delta_time_beg`
#' - `delta_time_end`
#' - `latitude_20m`
#' - `longitude_20m`
#' - `rgt`
#' - `n_seg_ph`
#' - `ph_ndx_beg`
#' - `segment_landcover`
#' - `segment_snowcover`
#' - `segment_watermask`
#' - `surf_type`
#' - `urban_flag`
#' - `night_flag`
#' - `permafrost_alt`
#' - `permafrost_prob`
#' - `cloud_flag_atm`
#' - `cloud_fold_flag`
#' - `column_od_asr`
#' - `brightness_flag`
#' - `layer_flag`
#' - `msw_flag`
#' - `psf_flag`
#' - `sat_flag`
#' - `asr`
#' - `atlas_pa`
#' - `beam_azimuth`
#' - `beam_coelev`
#' - `solar_azimuth`
#' - `solar_elevation`
#' - `snr`
#' - `dem_flag`
#' - `dem_removal_flag`
#' - `dem_h`
#' - `h_dif_ref`
#' - `last_seg_extend`
#' - `sigma_h`
#' - `sigma_along`
#' - `sigma_across`
#' - `sigma_topo`
#' - `sigma_atlas_land`
#'
#'
#' ## ATL08 Canopy attributes
#'
#' - `can_noise`
#' - `can_quality_score`
#' - `canopy_h_metrics_abs`
#' - `canopy_openness`
#' - `h_canopy`
#' - `canopy_rh_conf`
#' - `h_median_canopy_abs`
#' - `h_min_canopy`
#' - `h_mean_canopy_abs`
#' - `h_median_canopy`
#' - `h_canopy_abs`
#' - `toc_roughness`
#' - `h_min_canopy_abs`
#' - `h_dif_canopy`
#' - `h_canopy_quad`
#' - `h_canopy_20m`
#' - `n_ca_photons`
#' - `photon_rate_can`
#' - `photon_rate_can_nr``
#' - `centroid_height`
#' - `canopy_h_metrics_abs`
#' - `h_mean_canopy`
#' - `subset_can_flag`
#' - `canopy_h_metrics`
#' - `n_toc_photons`
#' - `h_max_canopy_abs`
#' - `h_canopy_uncertainty`
#' - `canopy_openness`
#' - `h_max_canopy`
#' - `segment_cover`
#'
#'
#' ## ATL08 Terrain attributes
#'
#' - `h_te_best_fit`
#' - `h_te_best_fit_20m`
#' - `h_te_interp`
#' - `h_te_max`
#' - `h_te_mean`
#' - `h_te_median`
#' - `h_te_mode`
#' - `h_te_rh25`
#' - `h_te_skew`
#' - `h_te_std`
#' - `h_te_uncertainty`
#' - `n_te_photons`
#' - `photon_rate_te`
#' - `subset_te_flag`
#' - `terrain_slope`
#' - `te_quality`
#'
#' @seealso \url{https://nsidc.org/sites/default/files/documents/technical-reference/icesat2_atl08_atbd_v007.pdf}
#'
#' @examples
#' if (requireNamespace("hdf5r", quietly = TRUE)) {
#' # Specifying the path to ATL08 file
#' atl08_path <- system.file("extdata",
#'   "atl08_clip.h5",
#'   package = "ICESat2VegR"
#' )
#'
#' # Reading ATL08 data (h5 file)
#' atl08_h5 <- ATL08_read(atl08_path = atl08_path)
#'
#' # Extracting ATL08-derived terrain and canopy attributes
#' atl08_seg_att_dt <- ATL08_seg_attributes_dt(atl08_h5 = atl08_h5)
#' head(atl08_seg_att_dt)
#'
#' close(atl08_h5)
#' }
#' @export
ATL08_seg_attributes_dt <- function(atl08_h5,
                                    beam = c("gt1l", "gt1r", "gt2l", "gt2r", "gt3l", "gt3r"),
                                    attributes = c(
                                      "delta_time",
                                      "h_canopy",
                                      "canopy_openness",
                                      "h_te_mean",
                                      "terrain_slope"
                                    )) {
  # Check file input
  if (!inherits(atl08_h5, "icesat2.atl08_h5")) {
    stop("atl08_h5 must be an object of class 'icesat2.atl08_h5' - output of [ATL08_read()] function ")
  }


  # Check beams to select
  groups_id <- atl08_h5$beams

  check_beams <- groups_id %in% beam
  beam <- groups_id[check_beams]

  attribute.dt <- data.table::data.table()

  pb <- utils::txtProgressBar(min = 0, max = length(beam), style = 3, file = stderr())

  i_s <- 0

  if (length(attributes > 0)) {
    for (i in beam) {
      i_s <- i_s + 1
      utils::setTxtProgressBar(pb, i_s)
      atl08_h5_beam <- atl08_h5[[i]]

      if (!atl08_h5_beam$exists("land_segments/latitude")) {
        next
      }
      lat_i <- atl08_h5_beam[["land_segments/latitude"]][]
      lon_i <- atl08_h5_beam[["land_segments/longitude"]][]

      m <- data.table::data.table(
        latitude = lat_i,
        longitude = lon_i,
        beam = i,
        strong_beam = i %in% atl08_h5$strong_beams
      )

      for (col in attributes) {
        # print(col)

        metric_address <- ATL08.var.map[[col]]
        base_addr <- gsub("^(.*)/.*", "\\1", paste0(i, metric_address))
        full_addr <- paste0(i, metric_address)


        if (is.null(metric_address)) {
          if (atl08_h5$exists(full_addr)) {
            metric_address <- col
          } else {
            if (i_s == 1) {
              warning(
                sprintf(
                  "The column '%s' is not available in the ATL08 product!",
                  col
                )
              )
            }
            m[, eval(col) := NA]
            next
          }
        }

        # base_addr <- gsub("^(.*)/.*", "\\1", metric_address)
        # atl08_h5$exists(base_addr) &&
        if (atl08_h5$exists(full_addr)) {
          if (col %in% c("h_canopy_20m", "canopy_h_metrics_abs", "subset_can_flag", "canopy_h_metrics", "longitude_20m", "latitude_20m")) {
            m <- cbind(m, t(atl08_h5[[full_addr]][, ]))

            if (col == "h_canopy_20m") {
              colnames(m)[(ncol(m) - 4):ncol(m)] <- paste0("h_canopy_20m_geo_", 1:5)
            }
            if (col == "longitude_20m") {
              colnames(m)[(ncol(m) - 4):ncol(m)] <- paste0("longitude_20m_", 1:5)
            }
            if (col == "latitude_20m") {
              colnames(m)[(ncol(m) - 4):ncol(m)] <- paste0("latitude_20m_", 1:5)
            }
            if (col == "canopy_h_metrics_abs") {
              colnames(m)[(ncol(m) - 17):ncol(m)] <- paste0("AH", seq(10, 95, 5))
            }
            if (col == "subset_can_flag") {
              colnames(m)[(ncol(m) - 4):ncol(m)] <- paste0("subset_can_flag_geo_", 1:5)
            }
            if (col == "canopy_h_metrics") {
              colnames(m)[(ncol(m) - 17):ncol(m)] <- paste0("RH", seq(10, 95, 5))
            }
          } else {
            set(m, j = col, value = atl08_h5[[full_addr]][])
          }
        }
      }
      attribute.dt <- data.table::rbindlist(list(attribute.dt, m), fill = TRUE)
    }
  }

  close(pb)

  prepend_class(attribute.dt, "icesat2.atl08_dt")
  return(attribute.dt)
}
