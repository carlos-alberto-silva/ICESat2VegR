test_that("configure preserves the published positional arguments", {
  expect_identical(names(formals(ICESat2VegR_configure))[1:9],
    c("envname", "py_ver", "prefer_conda", "force_conda_forge",
      "allow_session_installs", "manage_aiobotocore", "auto_restart",
      "verbose", "quick_probe"))
})

test_that("configure declares managed requirements before starting Python", {
  withr::local_envvar(c(CONDA_DEFAULT_ENV = NA))
  events <- character()
  started <- FALSE
  testthat::local_mocked_bindings(
    conda_list = function(...) data.frame(name = character()),
    py_available = function(initialize = FALSE) {
      if (initialize && !started) {
        events <<- c(events, "start")
        started <<- TRUE
      }
      started
    },
    py_require = function(packages, ...) {
      events <<- c(events, "requirements")
      expect_true("earthaccess" %in% packages)
    },
    py_module_available = function(module) TRUE,
    py_config = function() list(python = "test-python", version = "3.10"),
    .package = "reticulate"
  )
  expect_true(ICESat2VegR_configure(verbose = FALSE))
  expect_identical(events, c("requirements", "start"))
})

test_that("configure reuses a complete active Python without installing", {
  withr::local_envvar(c(CONDA_DEFAULT_ENV = NA))
  testthat::local_mocked_bindings(
    py_available = function(...) TRUE,
    py_module_available = function(module) TRUE,
    py_config = function() list(python = "test-python", version = "3.10"),
    py_require = function(...) stop("must not install"),
    py_install = function(...) stop("must not install"),
    .package = "reticulate"
  )
  expect_true(ICESat2VegR_configure(verbose = FALSE))
})

test_that("configure reports missing Python without downloading Miniconda", {
  withr::local_envvar(c(CONDA_DEFAULT_ENV = NA))
  testthat::local_mocked_bindings(
    conda_list = function(...) data.frame(name = character()),
    conda_binary = function(...) stop("conda unavailable"),
    py_available = function(...) FALSE,
    py_config = function() stop("Python unavailable"),
    install_miniconda = function(...) stop("must not download"),
    .package = "reticulate"
  )
  expect_message(
    result <- ICESat2VegR_configure(allow_managed_env = FALSE,
      allow_session_installs = FALSE, auto_install_miniconda = FALSE,
      auto_restart = FALSE, verbose = FALSE),
    "could not provide every required Python module"
  )
  expect_false(result)
})

test_that("conda failures use pip through the conda installation method", {
  withr::local_envvar(c(CONDA_DEFAULT_ENV = NA))
  method_used <- NULL
  testthat::local_mocked_bindings(
    py_available = function(...) TRUE,
    py_module_available = function(module) FALSE,
    py_config = function() list(python = "test-python", version = "3.10"),
    conda_list = function(...) data.frame(name = "test-env"),
    conda_binary = function(...) "test-conda",
    py_install = function(packages, envname, method, conda, pip, ...) {
      method_used <<- method
      expect_identical(envname, "test-env")
      expect_true(pip)
    },
    .package = "reticulate"
  )
  configure <- ICESat2VegR_configure
  environment(configure) <- list2env(list(
    system2 = function(...) structure("simulated conda failure", status = 1L)
  ), parent = environment(configure))
  suppressMessages(result <- configure(envname = "test-env",
    allow_session_installs = FALSE, auto_restart = FALSE, verbose = FALSE))
  expect_false(result)
  expect_identical(method_used, "conda")
})
